function [monitor, win, colour,vbl] = SetupPsychGUI(SkipSync)
%% Psychtoolbox setup
try
    %% Setting Up Screen
        
        AssertOpenGL;

        % Choose screen   
        if SkipSync == 1
            Screen('Preference', 'SkipSyncTests', 1); % 1 - Enable, 0 - Disable
            Screen('Preference','VisualDebugLevel', 0);
        end
        
        monitor.Num = max(Screen('Screens'));    %display on external screen if available      

        % Find resolution of the screen and pointer to center
        monitor.res = Screen('Resolution', monitor.Num);
        monitor.res = [monitor.res.width , monitor.res.height];
        monitor.CenterX = monitor.res(1)/2;
        monitor.CenterY = monitor.res(2)/2;
        monitor.Xres = monitor.res(1);
        monitor.Yres = monitor.res(2);
        

        % Open an onscreen window
        [win.Ptr, win.rect] = Screen('OpenWindow', monitor.Num, [], [], [], 2); %2 - numberOfBuffers
        %[win.Ptr, win.rect] = Screen('OpenWindow', monitor.Num, [], [0 0 400 200], [], 2); %2 - numberOfBuffers

             
        
        
        
        topPriorityLevel = MaxPriority(win.Ptr);
        Priority(topPriorityLevel);

        % Give the display a moment to recover from the change of display mode when
        % opening a window. It takes some monitors and LCD scan converters a few seconds to resync.
        WaitSecs(2);

        % Get timing information on current screen
        monitor.FlipInterval = 1/Screen('GetFlipInterval', win.Ptr); %actual monitor's refresh interval
        monitor.Hz = Screen('NominalFrameRate', win.Ptr); %Returns the nominal video frame rate in Hz, as reported by your computer's video driver
        
        % Define Colours black and white
        colour.black = BlackIndex(win.Ptr);
        colour.white = WhiteIndex(win.Ptr);
        colour.yellow = [255 221 23];
        colour.green = [0 161 75];
        colour.orange = [247 147 29];
        colour.red = [224 65 58];
        colour.grey = [114 114 114];
        
        HideCursor; %HIDE FOR EXPERIMENT
        
        % Initial flip to a blank screen:
         vbl = Screen('Flip',win.Ptr);
            
catch ME
    disp(ME);
    sca;
    close all;
end

end

