  %  Last Updated:
%  This is the main program for the cued experiment

close all; clear all; clc;

% Standard setting up of Psychtoolbox
% Here we call some default settings for setting up Psychtoolbox
PsychDefaultSetup(2);

% Get the screen numbers
screens = Screen('Screens');

% Draw to the external screen if avaliable
screenNumber = max(screens);

myScreen = max(Screen('Screens'));

SkipSync = 1; % Change for accurate synchronization  % 1 - Enable, 0 - Disable

[monitor, win, colour, vbl] = SetupPsychGUI(SkipSync);

% % Start recording the screen 
% PsychRecordScreen('Start', 0, 'video.mp4'); 

try
    % Display start of session - blank screen
    Screen('FillRect', win.Ptr, colour.black);

    % Instructions
    Screen('DrawText', win.Ptr, 'INSTRUCTIONS:', 40, 40, colour.white);
    Screen('DrawText', win.Ptr, '1. The left and right boxes will start to flicker.', 40, 240, colour.red);
    Screen('DrawText', win.Ptr, '2. Focus on the flickering box you want to activate.', 40, 280, colour.white);
    Screen('DrawText', win.Ptr, '3. Look straight ahead to move straight.', 40, 320, colour.white);
    Screen('DrawText', win.Ptr, '4. Press any key to EXIT.', 40, 360, colour.white);

    Screen('Flip', win.Ptr);
    WaitSecs(0.5);

    % Start flickering Stimuli
    square_flicker(colour.white, win.Ptr, win.rect);

    %Closing Psychtoolbox
    Screen('CloseAll');
    Screen('Close');

catch
    %this "catch" section executes in case of an error in the "try" section
    %above.  Importantly, it closes the onscreen window if its open.
    disp('Error Here')
    Screen('CloseAll');
    Screen('Close');
    psychrethrow(psychlasterror);
end %try..catch..

% % Stop recording 
% PsychRecordScreen('Stop'); 
