function square_flicker(red, win, winRect)

    %%Initiate frequency
    % Frames Period Freq. Simulated signal. 0 light. 1 dark
    % [#]   [ms]         [Hz]            [-]
    % 2   13.88   72      1 0
    % 3   20.83   48      0 1 1
    % 4   27.77   36      0 0 1 1
    % 5   34.72   28.8    0 0 1 1 1
    % 6   41.66   24      0 0 0 1 1 1
    % 7   48.61   20.57   0 0 0 1 1 1 1
    % 8   55.55   18      0 0 0 0 1 1 1 1
    % 9   62.5    16      0 0 0 0 1 1 1 1 1
    % 10  69.44   14.4    0 0 0 0 0 1 1 1 1 1
    % 11  76.39   13.09   0 0 0 0 0 1 1 1 1 1 1  
    % 12  83.33   12      0 0 0 0 0 0 1 1 1 1 1 1 
    % 13  90.33   11.08   0 0 0 0 0 0 1 1 1 1 1 1 1
    % 14  97.27   10.29   0 0 0 0 0 0 0 1 1 1 1 1 1 1
    % 15  104.16  9.6     0 0 0 0 0 0 0 1 1 1 1 1 1 1 1
    % 16  111.11  9       0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1
    % 17  118.06  8.47    0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1
    % 18  125     8       0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1
    % 19  132.1   7.58    0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1
    % 20  138.88  7.2     0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1
    % 21  145.98  6.86    0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1
    % 22  152.9   6.54    0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1

    F_72=   [1 0]
    F_48=   [0 1 1];
    F_36=   [0 0 1 1];
    F_28_8= [0 0 1 1 1];
    F_24=   [0 0 0 1 1 1];
    F_20_57=[0 0 0 1 1 1 1];
    F_18=   [0 0 0 0 1 1 1 1];
    F_16=   [0 0 0 0 1 1 1 1 1];
    F_14_4= [0 0 0 0 0 1 1 1 1 1];
    F_13_09=[0 0 0 0 0 1 1 1 1 1 1];  
    F_12=   [0 0 0 0 0 0 1 1 1 1 1 1]; 
    F_11_08=[0 0 0 0 0 0 1 1 1 1 1 1 1];
    F_10_29=[0 0 0 0 0 0 0 1 1 1 1 1 1 1];
    F_9_6=  [0 0 0 0 0 0 0 1 1 1 1 1 1 1 1];
    F_9=    [0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1];
    F_8_47= [0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1];
    F_8=    [0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1];
    F_7_58= [0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1];
    F_7_2=  [0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1];
    F_6_86= [0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1];
    F_6_54= [0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1];
    

    %According to the paper 1 is blackbox, 0 is white

    % initiate freq table
    freq{1} = F_9; %4/8 up
    freq{3} = F_16; %3/5 down

    freq{2} = F_13_09; %3/6 %RIGHT stimulus
    freq{4} = F_20_57; %LEFT stimulus


    %%Generate display matrixes for movies
    % Find LCM of freq matrix to create equal matrixes for all freqs
    lcmFreq = lcms([length(freq{1}), length(freq{2}), length(freq{3}), length(freq{4})]);
    %Generate full movie matrix of frequency
    for i = 1:4
        freqCombine(i, :) = repmat(freq{i}, 1, lcmFreq / length(freq{i}));
    end

    %Revert value because in Matlab 255 is white and 0 is black
    freqCombine = 1 - freqCombine;

%     maxduration = 50;

    if nargin < 2
        frequency = 5;
    end

    [width, height] = RectSize(winRect);

    % Get the centre coordinate of the window
    [xCenter, yCenter] = RectCenter(winRect);

    try
        Screen('FillRect', win, [0 0 0]);

        %%Make movie
        targetWidth = 300;
        targetHeight = 200;
        % make textures clipped to screen size
        % Draw texture to screen: Draw 16 states or texture depens on the value of
        screenMatrix = flickerTexture(width, height, targetWidth, targetHeight);

        for i = 1:16
            texture(i) = Screen('MakeTexture', win, uint8(screenMatrix{i}) * 255);
        end

        % Define refresh rate.
        ifi = Screen('GetFlipInterval', win);

        % Preview texture briefly before flickering
        % n.b. here we draw to back buffer
        Screen('DrawTexture', win, texture(16)); %texture(9) is left % texture(3) is right
        VBLTimestamp = Screen('Flip', win, ifi);
        WaitSecs(1);

        % loop swapping buffers, checking keyboard, and checking time
        % param 2 denotes "dont clear buffer on flip", i.e., we alternate
        % our buffers cum textures
        indexflip = 1;
        % textureValue =0;
        halfifi = 0.5 * ifi;
        vbl = 0;

        % Get the size of the on screen window
        [screenXpixels, screenYpixels] = Screen('WindowSize', win);

        % Screen X positions of our three rectangles
        squareXpos = [screenXpixels * 0.07 screenXpixels * 0.5 screenXpixels * 0.93];

        % Make a base Rect of 200 by 200 pixels
        baseRect = [0 0 70 30];

            %% Start looping movie
            Priority(1);
            
            while (~KbCheck)
                % Drawing
                %Compute texture value based on display value from freq long matrixes
                textureValue = freqCombine(:, indexflip) .* [1; 2; 4; 8];
                textureValue = textureValue(4) + textureValue(3) + textureValue(2) + textureValue(1) +1;
                %Draw it on the back buffer
                Screen('DrawTexture', win, texture(textureValue));
                %Display current index
                Screen('DrawText', win, num2str(indexflip),400,400, 255);

                % Fliping
                %Screen('Flip', win, vbl + halfifi);
                %Flip ASAP
                Screen('Flip', win);
                 indexflip = indexflip + 1;
                % indexflip = 6 ;
                %Reset index at the end of freq matrix
                if indexflip > lcmFreq
                    indexflip = 1;
                    %disp('over');
                end

            end % Flickering targets

        Priority(0);
        frame_duration = Screen('GetFlipInterval', win);
        Screen('DrawingFinished', win);
        Screen('CloseAll');
        Screen('Close');
    catch
        Screen('CloseAll');
        Screen('Close');
        psychrethrow(psychlasterror);
    end
